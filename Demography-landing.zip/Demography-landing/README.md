# Проект "Демография"
## Вариант вёрстки страниц

В данном репозитории вы найдете примеры верстки с помощью **HTML+CSS**, а также при помощи **Bootstrap**.
Здесь Вы также найдёте:
- HTML-коды
- CSS-коды
- Подключение Bootstrap
  
![Альтернативный текст](https://github.com/ipapMaster/Demography/blob/master/images/python.png)
